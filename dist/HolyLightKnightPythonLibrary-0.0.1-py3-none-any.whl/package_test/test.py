def func():
    print("test")